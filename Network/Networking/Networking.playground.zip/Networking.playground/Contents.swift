import Cocoa
//main
//DispatchQueue.main.async {
//
//}
////-global
//DispatchQueue.global(qos: .userInteractive).async {
//    //지금 당장 해야하는 일
//}
//
//DispatchQueue.global(qos: .userInitiated).async {
//    // 거의 바로 해줘야 할것 , 사용자가 결과를 기다림
//}
//
//DispatchQueue.global(qos: .utility).async {
//    //굳이?
//}
//DispatchQueue.global(qos: .background).async {
//    <#code#>
//}
//
////custom Queue
//let concurrntQueue = DispatchQueue(label: "concur", qos: .background, attributes: .concurrent)
//
//func updateUI()  -> Int {
//    return 2
//}
//func downloadImage() -> Int {
//
//    return 1
//}
////복합적인 상황
//DispatchQueue.global(qos: .background).async {
//    //download
//    let image = downloadImage()
//
//    // UI
//    DispatchQueue.main.async {
//        updateUI()
//    }
//
//}

//async
DispatchQueue.global(qos: .background).async {
    for i in 0...5 {
        print("😈\(i)")
    }
}
DispatchQueue.global(qos: .background).async {
    for i in 0...5 {
        print("🥚\(i)")
    }
}
